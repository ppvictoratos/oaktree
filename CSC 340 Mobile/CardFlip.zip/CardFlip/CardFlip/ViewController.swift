//
//  ViewController.swift
//  CardFlip
//
//  Created by Peter Victoratos on 3/4/19.
//  Copyright © 2019 Peter Victoratos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    var oneClubs = (UIImage(named: "1_of_clubs"))
    var twoClubs = (UIImage(named: "2_of_clubs"))
    var threeClubs = (UIImage(named: "3_of_clubs"))
    var fourClubs = (UIImage(named: "4_of_clubs"))
    var fiveClubs = (UIImage(named: "5_of_clubs"))
    var sixClubs = (UIImage(named: "6_of_clubs"))
    var sevenClubs = (UIImage(named: "7_of_clubs"))
    var eightClubs = (UIImage(named: "8_of_clubs"))
    var nineClubs = (UIImage(named: "9_of_clubs"))
    var tenClubs = (UIImage(named: "10_of_clubs"))
    
    let sample = [oneClubs, twoClubs, threeClubs, fourClubs, fiveClubs, sixClubs, sevenClubs, eightClubs, nineClubs, tenClubs]
    
    func dealCards(input: Array<Any>) -> Array<Any> {
        //randomize the array
        let shuff = input.shuffled()
        //take the first 8 elements
        let firstEight = shuff.removeSubgrange<R>(7)
        //duplicate it
        let secondEight = firstEight.copy()
        let sixteen = firstEight + secondEight
        //randomize that
        let final = sixteen.shuffled()
        return final
    }
    
    //load those into the card places every new game
    //if match, score += 1

}

